<?php    
	define("DB_TYPE", "mysql");
    define("DB_HOST", "localhost");
    define("DB_NAME", "ticbgnco_BrayhanOrtega_appweb");
    define("DB_USER", "ticbgnco");
    define("DB_PASS", "Ticosrifan18."); 