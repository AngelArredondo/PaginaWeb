<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">  
    <title>Mi Pagina Web</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
      <meta charset="utf-8">

<title>Menú</title>
		
 <link href="logo-pesta%C3%B1a.png" type="image/x-icon" rel="shortcut icon" />
    </head>
<body>
<nav>
<h1> <!--titulo--> </h1>
   
        <div class="login">
                    <aside id="datos">
		<form id="formulario2" action="proceso.php" method="POST" >
		
		<tr>
			<td> <label for="usuario">Usuario :</label></td>
			<td><input type="text" id="txtusr" name="txtusr" placeholder="Usuario" autofocus></td>
		</tr>  
		<tr>
			<td><label for="passwrd">Password :</label></td>
			<td><input type="password" id="txtpwd" name="txtpwd" ></td>
		</tr>
		<tr>
			<td><input type="submit" name="btn" value="Aceptar" id="btn"></td>
		</tr>

		</form>
	
	</aside>
            </div>
            
    
    <div class="solo">
                            <p>.</p>
                        </div>
                       

</nav>
     <div class="slider">
        <ul>
            <li><img src="Madara1-.png" width="180" height="200"></li>
            <li><img src="Madara2-.jpg"width="180" height="200"></li>
            <li><img src="Madara3-.jpg"width="180" height="200"></li>
            <li><img src="Madara5-.jpg"width="180" height="200"></li>
            
        </ul>
    </div>
     
 <body>
     
    
    </body>
    
            
                                   
        <div class="caja">
            <div class="cabecera">
                <p><!--Contenido de la cabecera--></p>
            </div>
        <div class="menu">
                    <ul id="BOX">
                    <li><a href="index.html" class="home">Home</a></li>
                    <li><a href="#" class="featured">Bienvenidos</a></li>
                    <li><a href="https://personalbloomb.blogspot.mx/2016/06/blog-pers-onal-brayhan-ortega-medina.html" class="people">Mi Blog</a></li>
                    <li><a href="#" class="music">Musica</a></li>
                    <li><a href="#" class="mixes">Mixes</a></li>
                    <li><a href="#" class="videos">Videos</a></li>
                    <li><a href="#" class="radio">Radio</a></li>
                </ul>
        </div>    
        <div class="contenido">
               
       <article >
           <div class="ingresar">
                    <aside id="datos2">
		<form id="formulario1"  method="POST" >
		<table>
		<tr>
			<td> <label for="usuario">Usuario:</label></td>
			<td><input type="text" id="txtusuario2" name="txtusuario" placeholder="Usuario" autofocus></td>
		</tr>  
		<tr>
			<td><label for="passwrd">Password:</label></td>
			<td><input type="password" id="txtpass2" name="txtpass" placeholder="Contraseña" ></td>
		</tr>
            <tr>
			<td> <label for="Conf.Contraseña">Conf.Contraseña:</label></td>
			<td><input type="password" id="txtconfpass2" name="txtusuario" placeholder="Confirmar contraseña" ></td>
		</tr>  
		<tr>
			<td><input type="submit" name="btn2" value="Aceptar" id="btnacep2"></td>
		</tr>
</table>
		</form>
	
	</aside>
            </div>
<?php
    require_once 'control/usuarios.php';
    $clsUsuarios=new usuarios();
    $dsUsuarios=$clsUsuarios->getUsers();
    $tablausuarios="<table id='listaUsuarios'>";
    //$tablausuarios=$tablausuarios."<th>"."<input type=".'"image"'."id=".'"botonbo"'."src=".'"borrar.png"'."/>"."</th>";
    $tablausuarios=$tablausuarios."<thead>";
    $tablausuarios=$tablausuarios."<tr>";
    $tablausuarios=$tablausuarios."<th>ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>";
    $tablausuarios=$tablausuarios."<th>USUARIO</th>";
    $tablausuarios=$tablausuarios."<th>ACTUALIZAR</th>";
    //$tablausuarios=$tablausuarios."<th>BORRAR</th>";  
    //$tablausuarios=$tablausuarios."<th>"."<input type=".'"image"'."id=".'"botonac"'."src=".'"actualizar.png"'."/>"."</th>";
    //$tablausuarios=$tablausuarios."<input type='button' id='btnBorrar' value='borrar'/>";
    $tablausuarios=$tablausuarios."</tr>";
    $tablausuarios=$tablausuarios."</thead>";
    $tablausuarios=$tablausuarios."<tbody>";
    
if(sizeof($dsUsuarios)>0){
    foreach($dsUsuarios as $usuario){
        $tablausuarios=$tablausuarios."<tr>";

        
        $tablausuarios=$tablausuarios."<td><input type='checkbox' id=".$usuario->getId().">&nbsp;&nbsp;&nbsp;".$usuario->getId()."</td>";
      //  $tablausuarios=$tablausuarios."<td>&nbsp;&nbsp;&nbsp;".$usuario->getId()."</td>"
        $tablausuarios=$tablausuarios."<td>&nbsp;&nbsp;&nbsp;".$usuario->getUsername().'</td>';
        $tablausuarios=$tablausuarios."<td>"."&nbsp;&nbsp;&nbsp;&nbsp;<inputticbgnco_BrayhanOrtega_appweb
 type='button' id='btnActualizar' value='Actualizar'/></td>";
        //$tablausuarios=$tablausuarios."<td>"."<input type=".'"image"'."id=".'"botonbo"'."src=".'"borrar.png"'."/>"."</td>";
        $tablausuarios=$tablausuarios."</tr>";
        
}
}else{
        $tablausuarios = $tablausuarios."<tr>";
        $tablausuarios = $tablausuarios."<td>No existen Usuarios</td>";
        $tablausuarios = $tablausuarios."</tr>";
}
                
    $tablausuarios=$tablausuarios."</tbody>";
    $tablausuarios=$tablausuarios."</table>";
        echo $tablausuarios;
?>
               <div style="text-align:right">
             <button id="btnBorrar">Eliminar Registro</button>
			</div>

                </article>
        
    
        </div>
        <div class="destacados">
            
            <!--<p>Esta pagina es totalmente creada por Brayhan Ortega en HTML5 y CSS3 en la Uiversidad Tecnologica del Suroestes de Guanajuato en el grupo de 3°B de TIC</p>-->
            
        </div>
        <div class="pie">
            <p>Pagina creada por  "Brayhan Ortega Medina "</p>
           <div class="logo1">
                    <table>
                    <tr>
                        <td>
                            
                        <h3>Contacto: </h3>                  
               
                        </td>
                    </tr>
                    <td>
                        <a href="https://personalbloomb.blogspot.mx/2016/06/blog-pers-onal-brayhan-ortega-medina.html"><img src="Blogger_logo.png" width="40" height="40" id="#blog" ></a>
            
                    </td>
            </table>
            </div>
        </div>
    
    	
    </div>
    
    <script src="public/pluggins/jquery-2.2.4.min.js"></script>
    <script>
    $(document).ready(function(){
	// this is the id of the form
	$("#datos").find("form").on("submit", function (event) {
     event.preventDefault();
		$.ajax({
          url: "proceso.php", 
          type: "POST",
          //datos del formulario
          data: $(this).serialize(),
          //una vez finalizado correctamente
          success: function (response) {
		 	if(response!=""){
				alert(response); 
				// show response from the php script.	
			}
          }
     });
	});
    });
                      
    </script>
       <script>
        $("#btnBorrar").click(function (event) {
            $("input:checkbox:checked").each(function(){
                //alert("El checkbox con valor "+ $(this).attr("id")+"esta seleccionado");
                 var parametros = {
          		"ID": $(this).attr("id")
		  	  };
			
		  $.ajax({
	      url: "borrar.php", 
          type: "POST",
          //datos del formulario
          data: parametros,
          //una vez finalizado correctamente
          success: function (response) {
               location.reload();
		  },
          error: function (response) {
               alert(response);
		  },
		  });
            });
        });
                                             
    </script>	
</body>
</html>